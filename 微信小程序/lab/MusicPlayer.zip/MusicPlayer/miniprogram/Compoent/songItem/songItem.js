// Compoent/songItem/songItem.js
var app=getApp();
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    item:{
      type:Object,
      value:{}
    },
    singer:{
      type:String,
      value:{}
    }

  },

  /**
   * 组件的初始数据
   */
  data: {
    favor:false,
    counterId:null
  },
  pageLifetimes:{
    show:function(){
      let states=app.globalData.favorMusics;
      let index = this.properties.item.sid;
      this.setData({
        favor:states.favors[index],
        counterId:states.counterIds[index]
      })
    }
  },
  ready:function(){

  },
  /**
   * 组件的方法列表
   */
  methods: {
    handleClick:function(){
      var musicPlayer=app.globalData.player;
      app.globalData.playerState=1;
      app.globalData.musicPic=this.properties.item.poster;
      app.globalData.musicName=this.properties.item.name;
      app.globalData.musicUrl=this.properties.item.src;
      app.globalData.artistName=this.properties.singer;
      musicPlayer.setData({
        PlayState:app.globalData.playState,
        musicPic:app.globalData.musicPic,
        musicName:app.globalData.musicName,
        musicUrl:app.globalData.musicUrl,
        artistName:app.globalData.artistName
      })
      
      musicPlayer.change();
    },
    handleFavor:function(){
      this.setData({
        favor:!this.data.favor
      })

      if(this.data.favor){
        this.favorMusic();
      }else{
        this.disfavorMusic();
      }
    },
    favorMusic:function(){
      const db=wx.cloud.database()
      db.collection('music_favor').doc(this.data.counterId).update({
        data:{
          name:this.properties.item.name,
          favor:true
        },
        success:res=>{
          this.setData({
            count:1
          })
          wx.showToast({title:'已收藏'})
          console.log()
          console.log(app.globalData.songList[this.properties.item.sid])
          //app.globalData.songList=res
          app.globalData.songList.find(element=>element.sid==this.properties.item.sid).favor=true
          app.globalData.favorMusics.favors[this.properties.item.sid]=true
          app.globalData.favorMusics.counterIds[this.properties.item.sid] =this.data.counterId
          app.globalData.favorMusics.singers[this.proerties.item.sid]=this
        },
        fail:err=>{
          wx.showToast({
            icon:'none',
            title:'新增记录失败'
          })
          console.error('[数据库][新增记录]失败: ',err)
        }
      })
    },
    disfavorMusic:function(){
      if(this.data.counterId){
        const db = wx.cloud.database()
        db.collection('music_favor').doc(this.data.counterId).update({
          data:{
            favor:false
          },
          success:res=>{
            wx.showToast({
              title:'已取消收藏',
            })
            
            console.log(app.globalData.songList[this.properties.item.sid])
            app.globalData.songList.find(element=>element.sid==this.properties.item.sid).favor=false
            app.globalData.favorMusics.favors[this.properties.item.sid] =false
          },
          fail:err=>{
            wx.showToast({
              icon:'none',
              title:'删除失败',
            })
            console.error('[数据库][删除记录]失败: ',err)
          }
          
        })
      }else{
        wx.showToast({
          title:'无counterId,该歌曲还未收藏',
        })
      }
    }

  }
})
