var json=[
  {
    "name":"MyFavorMusic",
    "src":"http://p2.music.126.net/sbaFWjS3u_39XS617qAicw==/109951164485848375.jpg?param=200y200"
  },
  {
    "name":"Off",
    "src":"https://p2.music.126.net/dPZdc37ZPJ2Cfwbtzp_ttg==/109951165383284732.jpg?para=200y200"
  },
  {
    "name":"Lover",
    "src":"https://p2.music.126.net/zArZbgXW3ToJMMebPYcpYw==/109951164922652639.jpg?param=200y200"
  },
  { 
    "name":"Head Above Water",
    "src":"https://p1.music.126.net/zWsEuCErUJxjUO-izbKemw==/109951165151791026.jpg?param=200y200"
  }
]
module.exports={
  list:json
}