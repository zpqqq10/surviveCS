const DEFAULT_MUSIC={
  musicName:'七里香',
  artistName:'周杰伦',
  musicPic:"http://cdnmusic.migu.cn/picture/2019/1031/0254/ASd6c2d9697d2a4f5f96508c8a7ec8b1a8.jpg",
  musicUrl:"https://webfs.yun.kugou.com/202012241424/d4ea067d48e97b6be0989b3111ab2c7e/part/0/960083/G190/M08/1E/11/_g0DAF5OFGeAaInOAEolWWFdwH4496.mp3",
  playState:0
}
module.exports={
  DEFAULT_MUSIC
}