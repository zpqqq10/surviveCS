//app.js
import{DEFAULT_MUSIC} from './Config/index.js';
App({
  onLaunch: function () {
    // 展示本地存储能力
    if(!wx.cloud){
      console.error('请使用2.2.3或以上的基础库以使用云能力')
    }
    else{
      wx.cloud.init({
        env:'mmm-4g1vpuy139ba805a',
        traceUser:true,
      })
    }
    // var logs = wx.getStorageSync('logs') || []
    // logs.unshift(Date.now())
    // wx.setStorageSync('logs', logs)

    // // 登录
    // wx.login({
    //   success: res => {
    //     // 发送 res.code 到后台换取 openId, sessionKey, unionId
    //   }
    // })
    // // 获取用户信息
    // wx.getSetting({
    //   success: res => {
    //     if (res.authSetting['scope.userInfo']) {
    //       // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
    //       wx.getUserInfo({
    //         success: res => {
    //           // 可以将 res 发送给后台解码出 unionId
    //           this.globalData.userInfo = res.userInfo

    //           // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
    //           // 所以此处加入 callback 以防止这种情况
    //           if (this.userInfoReadyCallback) {
    //             this.userInfoReadyCallback(res)
    //           }
    //         }
    //       })
    //     }
    //   }
    // })
    this.globalData.audio.src=DEFAULT_MUSIC.musicUrl
    this.getFavorMusics()
  },

  globalData: {
    userInfo: null,
    audio:wx.createInnerAudioContext(),
    playState:DEFAULT_MUSIC.playState,
    musicPic:DEFAULT_MUSIC.musicPic,
    musicName:DEFAULT_MUSIC.musicName,
    musicUrl:DEFAULT_MUSIC.musicUrl,
    artistName:DEFAULT_MUSIC.artistName,
    musicPlayer:null,
    favorMusics:{},
    songList:{}
  },
  getFavorMusics:function(){
    //console.log("getFavorMusics")
    const db=wx.cloud.database()
    //console.log("getFavorMusics")
    db.collection('music_favor').field({
      sid:true,
      _id:true,
      name:true,
      favor:true,
      singer:true,
      src:true,
      poster:true,
      broadcast:true
    }).get({
      success:res=>{
        let favors = new Array(res.data.length+1);
        let counterIds=new Array(res.data.length+1);
        let singers = new Array(res.data.length+1);
        let names = new Array(res.data.length+1);
        res.data.forEach(function(item,index){
          favors[item.sid]=item.favor
          counterIds[item.sid] = item._id
          names[item.sid]=item.name
          singers[item.sid]=item.singer
        });
        this.globalData.favorMusics={
          counterIds:counterIds,
          favors:favors,
          names:names,
          singers:singers,
        };
        this.globalData.songList=res.data
        console.log(this.globalData.songList)
        //console.log(111);
        //console.log(this.globalData.favorMusics);
      },
      fail:err=>{
        wx.showToast({
          icon:'none',
          title:'查询记录失败'
        });
        console.error('[数据库][查询记录]失败: ',err);
      }
    })

  }
})