// components/recommand/recommand.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    item: {
      type: Object,
      value: {}
    },
    source: {
      type: String,
      value: ''
    } , 
    item1: {
      type: Object,
      value: {}
    },
    item2: {
      type: Object,
      value: {}
    }
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    onTap: function () {
      console.log('recommand', this.properties.item)
      //let url=encodeURIComponent(this.properties.item)
      wx.navigateTo({
        url: '/pages/noteDetail/noteDetail?encoded=' + encodeURIComponent(JSON.stringify(this.properties.item))
      })
      //这里同上因为noteDetail需要复用所以需要通过参数传递的方式来获得索引，出于方便我直接在noteDetail.js中创建了本地数据
    },
    onLongPress: function (e) {
      // console.log("its a long press");
      if (this.properties.source == 'notemanage') {
        var that = this
        wx.showActionSheet({
          itemList: ["修改笔记", "删除笔记"],
          success(res) {
            console.log(res.tapIndex)
            if (res.tapIndex == 0) {
              wx.navigateTo({
                url: `/pages/uploadnote/uploadnote?op=1&noteid=${that.properties.item._id}`,
              })
            }
            else {
              console.log(that.properties.item)
              const db = wx.cloud.database();
              db.collection('NOTE').where({
                _id: that.properties.item._id
              }).remove({
                success: res => {
                  var pages = getCurrentPages()
                  //刷新
                  // console.log('-1', pages[pages.length - 1])
                  pages[pages.length - 1].onLoad()
                }
              })

            }
          },
          fail(res) { console.log(res.errMsg) }
        })
      }
    }
  }
})