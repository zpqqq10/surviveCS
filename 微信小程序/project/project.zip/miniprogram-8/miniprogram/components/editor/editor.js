Component({
  properties: {
    option: {
      type: Object
    },
    html:{
      type:String
    }
  },
  data: {
    formats: {},
    readOnly: false,
    placeholder: '输入文字...',
    // editorHeight: 300,
    keyboardHeight: 0,
    isIOS: false
  },
  ready() {
    const platform = wx.getSystemInfoSync().platform
    const isIOS = platform === 'ios'
    this.setData({
      isIOS
    })
    const that = this
    this.updatePosition(0)
    let keyboardHeight = 0
    wx.onKeyboardHeightChange(res => {
      if (res.height === keyboardHeight) return
      const duration = res.height > 0 ? res.duration * 1000 : 0
      keyboardHeight = res.height
      setTimeout(() => {
        wx.pageScrollTo({
          scrollTop: 0,
          success() {
            that.updatePosition(keyboardHeight)
            that.editorCtx.scrollIntoView()
          }
        })
      }, duration)

    })
  },
  methods: {
    test(){
      console.log("abc");
    },
    readOnlyChange() {
      this.setData({
        readOnly: !this.data.readOnly
      })
    },
    updatePosition(keyboardHeight) {
      const toolbarHeight = 100
      const {
        windowHeight,
        platform
      } = wx.getSystemInfoSync()
      // let editorHeight = keyboardHeight > 0 ? (windowHeight - keyboardHeight - toolbarHeight) : windowHeight
      this.setData({
        // editorHeight,
        keyboardHeight
      })
    },
    calNavigationBarAndStatusBar() {
      const systemInfo = wx.getSystemInfoSync()
      const {
        statusBarHeight,
        platform
      } = systemInfo
      const isIOS = platform === 'ios'
      const navigationBarHeight = isIOS ? 44 : 48
      return statusBarHeight + navigationBarHeight
    },
    onEditorReady() {
      const that = this
      //组件使用createSelectorQuery加上in(this)
      console.log('see in editor', this.properties.html)
      wx.createSelectorQuery().in(that).select('#editor').context(function (res) {
        that.editorCtx = res.context
        that.editorCtx.setContents({
          html:that.properties.html    //这里就是设置默认值的地方（html 后面给什么就显示什么）
                        //that.data.content 是我存在 data 里面的数据
                        //注意是 this 赋值的 that，如果用 this 就把上面的 function 改成箭头函数
        });
      }).exec()
      
      
    },
    undo() {
      this.editorCtx.undo()
    },
    redo() {
      this.editorCtx.redo()
    },
    blur() {
      this.editorCtx.blur()
    },
    format(e) {
      let {
        name,
        value
      } = e.target.dataset
      if (!name) return
      // console.log('format', name, value)
      if (name === "backgroundColor" && value === "#ff0000") { //设置字体颜色为白色
        this.editorCtx.format("color", "#ffffff")
      }
      if (name === "backgroundColor" && value === "#ffffff") {
        this.editorCtx.format("color", "#000000")
      }
      if (name === "color") { //清楚字体样式
        this.editorCtx.removeFormat()
      }
      this.editorCtx.format(name, value)

    },
    onStatusChange(e) {
      const formats = e.detail
      this.setData({
        formats
      })
    },
    insertDivider() {
      this.editorCtx.insertDivider({
        success: function () {
          console.log('insert divider success')
        }
      })
    },
    clear() {
      this.editorCtx.clear({
        success: function (res) {
          console.log("clear success")
        }
      })
    },
    removeFormat() {
      this.editorCtx.removeFormat()
    },
    insertDate() {
      const date = new Date()
      const formatDate = `${date.getFullYear()}/${date.getMonth() + 1}/${date.getDate()}`
      this.editorCtx.insertText({
        text: formatDate
      })
    },
    insertImage() { //图片上传插入示例
      var that = this;
      console.log(111)
      wx.chooseImage({
        count: 1,
        sizeType: ['original', 'compressed'],
        sourceType: ['album', 'camera'],
        success: (res) => {
          const tempFilePath = res.tempFilePaths[0]
          const cloudPath =  "img/" + new Date().getTime() +"-"+ Math.floor(Math.random() * 1000);
    
          wx.cloud.uploadFile({
            cloudPath: cloudPath,
            filePath: tempFilePath,
            success: res => {
              console.log('fileid', res.fileID);
              var src=res.fileID
              that.editorCtx.insertImage({
                src,
                data: {
                  id: 'abcd',
                  role: 'god'
                },
                width: '80%',
                success: function () {
                  console.log('insert image success')
                }
              })
              console.log('fileid', res.fileID);
            }
          })
          // wx.uploadFile({ //调用图片上传接口
          //   url: 'http://192.168.1.61:3000/upload',
          //   filePath: tempFilePath,
          //   name: 'imgFile',
          //   success: res => {
          //     let imgUrl = JSON.parse(res.data).url
          //     console.log(imgUrl);
          //     that.editorCtx.insertImage({
          //       imgUrl,
          //       data: {
          //         id: 'abcd',
          //         role: 'god'
          //       },
          //       width: '80%',
          //       success: function () {
          //         console.log('insert image success')
          //       }
          //     })
          //   }
          // })
        },
        fail: (res) => {},  
        complete: (res) => {},
      })

    },
    getContent(e) { //获得文本内容
      this.triggerEvent('Content', {
        content: e.detail
      })
    }
  }
})