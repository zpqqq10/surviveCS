// components/curri/curri.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    item:{
      type:Object,
      value:[]
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    
  },

  /**
   * 组件的方法列表
   */
  methods: {
    onTap:function(){
      console.log(this.properties.item)
        var temp=encodeURIComponent(this.properties.item._id)
        wx.navigateTo({
          url: `/pages/FolderDetail/FolderDetail?id=`+temp,
        })
        //这里我才用了直接将下一级的目录作为参数传给FolderDetail，也就是说在这里拉好下一级文件夹里的内容传给下一级，
        //也可以采用拉下一级文件见的openid也就是索引，然后把索引传递过去，自己选择
      

    }
  }
})
