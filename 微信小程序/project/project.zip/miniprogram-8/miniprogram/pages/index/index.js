//index.js
const app = getApp()

Page({
  data: {
    avatarUrl: '/images/user-unlogin.png',
    userInfo: {},
    logged: false,
    takeSession: false,
    requestResult: '',
    swiperdata: ['../../images/index.png', '../../images/mengbi.png', '../../images/yousi.png'], 
    swipercur: 0, 
    rcmnote:[]
  },

  swiperchange: function(e){
    this.setData({
      swipercur: e.detail.current
    })
  }, 

  swipertap: function(){
    console.log(this.data.swipercur)
    if(this.data.swipercur==0){
      // wx.navigateTo({
      //   url: '/pages/noteDetail/noteDetail?encoded=' + JSON.stringify(this.properties.item)
      // })
      console.log('jump to the first')
    }
    else if(this.data.swipercur==1){
      wx.navigateTo({
        url: '/pages/noteDetail/noteDetail?encoded=' + encodeURIComponent(JSON.stringify(this.data.item1))
      })
      console.log('jump to the second')
    }
    else if(this.data.swipercur==2){
      wx.navigateTo({
        url: '/pages/noteDetail/noteDetail?encoded=' + encodeURIComponent(JSON.stringify(this.data.item2))
      })
      console.log('jump to the third')
    }
  }, 

  onLoad: function() {
    wx.authorize({scope: "scope.userInfo"}); 
    if (!wx.cloud) {
      wx.redirectTo({
        url: '../chooseLib/chooseLib',
      })
      return
    }
    wx.cloud.callFunction({
      name: 'login',
      data: {},
      success: res => {
        // console.log('[云函数] [login] user openid: ', res.result.openid)
        app.globalData.openid = res.result.openid
        const db=wx.cloud.database(); 
        db.collection('USER').where({
          _openid: app.globalData.openid
        }).get({
          success: res =>{
            // console.log('success', res.data)
            if(res.data.length==0) // a new user
            {
              db.collection('USER').add({
                data:{
                  favorlist: []
                }
              })
            }
          }, 
          fail: err =>{
            console.error(err)
          }
        })
      },
      fail: err => {
        console.error('[云函数] [login] 调用失败', err)
      }
    })
    // 获取用户信息
    wx.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
          wx.getUserInfo({
            success: res => {
              this.setData({
                avatarUrl: res.userInfo.avatarUrl,
                userInfo: res.userInfo
              })
              app.globalData.avatarUrl= res.userInfo.avatarUrl
              app.globalData.userInfo=res.userInfo
            }
          })
        }
      }
    })

    const db=wx.cloud.database(); 
    var that=this; 
    db.collection('NOTE').where({
      classified:true
    }).get({
      success: res=>{
        // console.log('get recommend', res.data)
        var temp=res.data; 
        that.setData({
          rcmnote:res.data
        })
        console.log(that.data.rcmnote)
      }
    })

    db.collection('NOTE').where({
      _id: 'ce805e785ffa637003db23d82c8eb9a8'
    }).get({
      success: res=>{
        that.setData({
          item1: res.data[0]
        })
        console.log('item1', that.data.item1)
      }
    })

    db.collection('NOTE').where({
      _id: 'ce805e785ffc02d503fdf1ce014dfa60'
    }).get({
      success: res=>{
        that.setData({
          item2: res.data[0]
        })
        console.log('item1', that.data.item2)
      }
    })
  },

  onGetUserInfo: function(e) {
    if (!this.data.logged && e.detail.userInfo) {
      this.setData({
        logged: true,
        avatarUrl: e.detail.userInfo.avatarUrl,
        userInfo: e.detail.userInfo
      })
    }
  },

  // 上传图片

})
