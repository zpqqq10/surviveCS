// miniprogram/pages/noteDetail/noteDetail.js
var app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    item: [],
    first: true,
    decoded: ''     // _id of current note
  },
  previewImgEvent(e) {
    let src = e.currentTarget.dataset.src;
    if (src && src.length > 0) {
      wx.previewImage({
        urls: [src]
      });
    }
  },
  reloadEvent() {
    var pages = getCurrentPages();
    //console.log('-2', pages[pages.length - 2])
    //console.log('-1', pages[pages.length - 1])
    console.log('reload')
    console.log(this.data.isCollect)
    pages[pages.length - 1].onLoad();
  },
  toCommentPage: function () {
    wx.navigateTo({
      url: '../../pages/comment/comment',
    })
  },
  collectOrNot: function () {
     console.log(this.data.isCollect)
     
    var that = this;
    var userfavorlist = [];
    const db = wx.cloud.database();
    // get favorlist
    db.collection('USER').where({
      _openid: app.globalData.openid
    }).get({
      success: res => {
        userfavorlist = res.data[0].favorlist
        //console.log('cloud favorlist', res.data[0].favorlist)
        //console.log('read favor local', userfavorlist)
        if (that.data.isCollect) {
          userfavorlist.splice(userfavorlist.indexOf(that.data.decoded), 1);
        }
        else {
          //console.log('decoded', that.data.decoded)
          //console.log('not pushed', userfavorlist)
          userfavorlist.push(that.data.decoded);
          //console.log('pushed list', userfavorlist)
        }
        
        // renew favorlist
        db.collection('USER').where({
          _openid: app.globalData.openid
        }).update({
          data: {
            favorlist: userfavorlist
          },
          success:res=>{
            wx.showToast({
              title: that.data.isCollect?'取消收藏':"已收藏",
              icon: 'success',
              duration: 1000,
              mask: true,
              success: function () {
                that.data.isCollect = that.data.isCollect ? 0 : 1;
                console.log(that.data.isCollect)
                that.reloadEvent();
              }
            })
            
          }
        })
      }
    })

    
  },
  showpdf: function () {
    console.log("pdf")
    wx.cloud.downloadFile({
      fileID: 'cloud://mmm-4g1vpuy139ba805a.6d6d-mmm-4g1vpuy139ba805a-1304600961/屑.pdf',
      success: function (res) {
        var filePath = res.tempFilePath
        wx.openDocument({
          filePath: filePath,
          success: function (res) {
            console.log('打开文档成功')
          }
        })
      }
    })

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const db = wx.cloud.database();
    var that = this;
    if (this.data.first) {
      this.setData({
        item: JSON.parse(decodeURIComponent(options.encoded)),
        first: false
      })
      this.setData({
        decoded: this.data.item._id
      })
      // console.log(this.data.decoded);
    }
    else {
      db.collection('NOTE').where({
        _id: that.data.decoded
      }).get({
        success: res => {
          console.log('refresh')
          that.setData({
            item: res.data[0]
          })
        }
      })
    }
    db.collection('USER').where({
      _openid: app.globalData.openid
    }).get({
      success: res => {
        // console.log(res.data[0])
        if (res.data[0].favorlist.indexOf(this.data.decoded) == -1) {
          this.setData({
            isCollect: 0
          })
        }
        else {
          this.setData({
            isCollect: 1
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    this.setData({
      first: true
    })
    // console.log('first: '+this.data.first)
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})