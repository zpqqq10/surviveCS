// miniprogram/pages/search/search.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    searchlist: [],
    input: '', 
    searchinput: '', 
    source: 0
  },

  search:function(){
    this.setData({
      input: this.data.searchinput
    })
    var pages=getCurrentPages(); 
    pages[pages.length-1].onLoad(); 
  },

  searchinput: function(e){
    this.setData({
      searchinput: e.detail.value
    })
    console.log(this.data.searchinput)
  }, 

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const db = wx.cloud.database();
    const _ = db.command;
    var that = this;
    if(this.data.source==0){
      this.setData({
        input: JSON.parse(decodeURIComponent(options.encoded)), 
        source: 1
      })
    }
    db.collection('NOTE').where(
      _.or([{
        tags: db.RegExp({
          regexp: '.*' + that.data.input,
          options: 'i'
        })
      },
      {
        title: db.RegExp({
          regexp: '.*' + that.data.input,
          options: 'i'
        })
      }, {
        column: db.RegExp({
          regexp: '.*' + that.data.input,
          options: 'i'
        })
      }])
    ).where({
      parent: _.neq(''), 
      type: 2
    }).get({
      success: res => {
        console.log(res.data)
        that.setData({
          searchlist: res.data
        })
        console.log('get object', that.data.searchlist)
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    this.setData({
      source: 0
    })
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})