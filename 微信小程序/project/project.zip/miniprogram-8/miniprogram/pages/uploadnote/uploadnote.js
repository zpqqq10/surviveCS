// miniprogram/pages/uploadnote/uploadnote.js
var app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  html:"",
  data: {
    html: '',
    option: {
      placeholder: '编写文章...', //占位符默认为 '请输入文字...'
      imgUp: false, //插入图片功能默认开启
      width: '100%', //默认宽100%
      height: '600rpx', //默认高200px
    },
    title: "",
    column: "",
    tags: "",
    noteid: '',
    op: 0
  },
  getHtml(e) { //从组件获取值
    this.html = e.detail.content.html
  },
  submit() {
    console.log('提交的富文本', this.html);
    var that = this;
    const db = wx.cloud.database();
    console.log("html",this.html)
    console.log("title",this.data.title)
    if(this.html.length==0||this.data.title.length==0)
    {
      wx.showToast({
        title:"标题与正文为空",
        icon:"error",
        image:"/images/error.png",
        duration:1000,
        mask:true
      })
    }
    else if (this.data.op == 0) {
      console.log(this.data.op);
      db.collection('NOTE').add({
        data: {
          title: that.data.title,
          column: that.data.column,
          tags: that.data.tags,
          html: that.html,
          image: app.globalData.userInfo.avatarUrl,
          classified: false,
          creator: app.globalData.userInfo.nickName,
          time: new Date(),
          cover: '',
          publicity: false,
          comment: [],
          parent: "",
          type: 2
        }
      });
      wx.showToast({
        title: '提交成功',
        icon: 'success',
        duration: 1000,
        mask: true,
        success: function () {
          setTimeout(function () {
            var pages = getCurrentPages()
            //对上一页进行刷新
            wx.navigateBack({
              success: res => {
                pages[pages.length - 2].onLoad()
              }
            });
          }, 1000)
        }
      })
    }
    else {
      db.collection('NOTE').where({
        _id: that.data.noteid
      }).update({
        data: {
          title: that.data.title,
          column: that.data.column,
          tags: that.data.tags,
          html: that.html,
          image: app.globalData.userInfo.avatarUrl,
          creator: app.globalData.userInfo.nickName,
          time: new Date(),
          cover: '',
          publicity: false,
          comment: [],
          type: 2
        }
      }); 
      wx.showToast({
        title: '更新成功',
        icon: 'success',
        duration: 1000,
        mask: true,
        success: function () {
          setTimeout(function () {
            var pages = getCurrentPages()
            //对上一页进行刷新
            wx.navigateBack({
              success: res => {
                pages[pages.length - 2].onLoad()
              }
            });
          }, 1000)
        }
      })
    }

  },
  titleinput: function (e) {
    this.setData({
      title: e.detail.value
    })
    // console.log('title: ', this.data.title)
  },
  columninput: function (e) {
    this.setData({
      column: e.detail.value
    })
  },
  tagsinput: function (e) {
    this.setData({
      tags: e.detail.value
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // console.log(options.op)
    this.setData({
      op: options.op,
      noteid: options.noteid
    })
    console.log(this.data.op)
    console.log('noteid', this.data.noteid)
    // 1->edit, 0->new
    if (options.op != 0) {
      console.log("fix")
      var that = this;
      that.setData({

      })
      const db = wx.cloud.database();
      db.collection('NOTE').where({
        _id: that.data.noteid
      }).get({
        success: res => {
          console.log('get success', res)
          that.setData({
            title: res.data[0].title,
            column: res.data[0].column,
            tags: res.data[0].tags,
            html: res.data[0].html
          })
          console.log('see html', that.data.html)
          var hf_editor = that.selectComponent("#hf_editor");
          hf_editor.onEditorReady();
        }
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    //   wx.showModal({
    //     title: '确认',
    //     content: '',
    //     success: function (res) {
    //         if (res.confirm) {
    //             console.log('用户点击确定')
    //         }else{
    //            console.log('用户点击取消')
    //         }

    //     }
    // })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})