module.exports = {
    appConfig: {
        appid: '/** your appid **/',
        secret: '/** your appSecret **/'
    },
    userConfig: {
        credit: 30          // 用户初始积分余额
    }
}