module.exports = {
    mysql: {
        host: '/** your database server ip **/',
        user: '/** your database user **/',
        password: '/** your database account password **/',
        database: '/** your database **/',
        port: 3306  // your database server port, default is 3306
    }
}