security

* 讲追求高性能的设计所隐含的安全隐患，可以同时讲到高性能与安全问题
* speech
  * intro一个人
  * 两个人side channel attack
  * 重点：一个人讲out-of-order & prediction，一个人讲meltdown & spectre， 一个人讲当今的应对措施
  * 一个人ending
  * 思考下怎么来点整活

9号前把topic定下来 → 13号前七个人看papers（顶会+综述） → 15号前各自整理出讲稿和ppt → 18



- [x]  CASINO Core Microarchitecture: Generating Out-of-Order Schedules Using Cascaded In-Order Scheduling Windows


- [x] Precise Runahead Execution

- [ ] Delay and Bypass: Ready and Criticality Aware Instruction Scheduling in Out-of-Order Processors

*Leaking Information Through Cache LRU States*

Improving Predication Efficiency through Compaction/Restoration of SIMD Instructions

A hierarchical neural model of data prefetching

Auto-predication of critical branches

InvisiSpec: Making Speculative Execution Invisible in the Cache Hierarchy (Corrigendum)

Pipette: Improving Core Utilization on Irregular Applications through Intra-Core Pipeline Parallelism

I-SPY: Context-Driven Conditional Instruction Prefetching with Coalescing

- [x] BranchNet: A Convolutional Neural Network to Predict Hard-To-Predict Branches



* International Symposium on High-Performance Computer Architecture
  * HPCA
  * https://www.hpca-conf.org/2020/accepted-papers/
  * https://www.computer.org/csdl/proceedings/hpca/2021/1t0HTDy6Pkc
* ACM International Conference on Architectural Support for Programming Languages and Operating Systems
  * ASPLOS
  * https://dl.acm.org/doi/proceedings/10.1145/3373376
  * https://dl.acm.org/doi/proceedings/10.1145/3445814
* The International Symposium on Computer Architecture
  * ISCA
  * https://dl.acm.org/doi/proceedings/10.5555/3426241
  * 21的似乎还没整出来
* International Symposium on Microarchitecture
  * MICRO
  * 19: https://dl.acm.org/doi/proceedings/10.1145/3352460
  * 20: https://www.computer.org/csdl/proceedings/micro/2020/1oFGBxwA7AI
  * 21年的准备办了



# pre

* machine learning accelerator
  * near-data-processing
* parallelism
* row hammer



instruction: 

* prediction

  * rule-based
    * tagged sequential prefetching
    * reference prediction tables (RPT)
    * Program Counter/Delta Correlation Prefetching (PC/DC) 

  * machine learning-based
    * slow training and prediction
    * computation cost

* out-of-order
  * reservation



data: 

* prefetch
  * machine learning
  * helper thread
  * statistic
* cache replacement
  * machine learning

> Although the capacity of DRAM increasesby about 40% per year, the latency only decreases by about 6-7% per year [4].  This gapbetween the processor and DRAM leads to a performance problem known as the“memorywall”(or“memory gap”) . Numerous  techniques  have  been  developed  to  tolerate  orcompensate for this gap, including out-of-order execution, caches and prefetching
>
> [Storage Efficient Hardware Prefetching usingDelta-Correlating Prediction Tables](https://www.jilp.org/vol13/v13paper2.pdf)





##### Intro

以一段代码为引子，点出计算机发展至今人们为了追求运行的效率和速度，

> what software is supposed to do is different from what the processor actually does

数据和指令是提升运行速度的研究重点。比如，指令方面，人们研究如何让指令执行的速度更快，发展出了speculative execution；数据方面，人们研究如何让获取数据的速度跟上指令执行的速度，发展出了prefetch。

##### out-of-order execution / prediction

* 原理/过程
* 效果
* 最新研究进展（顶会或其他论文）

##### prefetch

* 原理/过程
* 效果
* 最新研究进展（顶会或其他论文）
* 过渡一下下文，点出这些设计都伴随着安全隐患

##### side channel

* （先讲这个是考虑到这个也算是meltdown & spectre的一部分）
* 原理/过程&变种
* 危害性/危害的平台
* 最新研究进展或攻击手段（**没有就不讲这个**

##### meltdown & spectre

* 原理/过程&变种
* 危害性/危害的平台
* 最新研究进展或攻击手段（**没有就不讲这个**

##### defense against side channel

* 原理/过程
* 最新防御手段

##### defense against meltdown & spectre

* 原理/过程
* 最新防御手段
